<script>
// 相当于 app.js
export default {}
</script>

<style></style>
