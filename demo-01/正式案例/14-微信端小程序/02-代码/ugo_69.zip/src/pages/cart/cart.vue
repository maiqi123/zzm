<template>
  <view>购物车</view>
</template>

<script>
export default {}
</script>

<style></style>
