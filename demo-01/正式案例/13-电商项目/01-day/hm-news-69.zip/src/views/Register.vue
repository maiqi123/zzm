<template>
  <div>
    <!-- 头部 -->
    <hm-header>注册</hm-header>
    <!-- logo -->
    <hm-logo></hm-logo>
    <!-- 按钮 -->
    <hm-button>注册</hm-button>
    <h1>注册</h1>
  </div>
</template>

<script>
export default {}
</script>

<style scoped></style>
