<template>
  <div>
    <!-- 头部 -->
    <hm-header>登录</hm-header>
    <!-- logo -->
    <hm-logo></hm-logo>
    <!-- 按钮 -->
    <hm-button>登录</hm-button>

    <h1>登录</h1>
  </div>
</template>

<script>
export default {}
</script>

<style lang="less" scoped>
h1 {
  color: red;
}
</style>
