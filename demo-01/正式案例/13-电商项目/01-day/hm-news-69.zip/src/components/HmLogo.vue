<template>
  <div class="hm-logo">
    <i class="iconfont iconnew"></i>
  </div>
</template>

<script>
export default {}
</script>

<style lang="less">
.hm-logo {
  text-align: center;
  .iconnew {
    font-size: 128px;
    color: red;
  }
}
</style>
