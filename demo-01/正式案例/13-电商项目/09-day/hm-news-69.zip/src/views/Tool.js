
/// 这里只有一个工具
// function test() {
  
// }

// export default test

// import test from  './Tool.js'


export function test1() {
  
}
export function test2() {
  
}
export function test3() {
  
}

import { test1,test2,test3 } from './tool.js'

// export default {
//   text1,
//   text2,
//   text3
// }